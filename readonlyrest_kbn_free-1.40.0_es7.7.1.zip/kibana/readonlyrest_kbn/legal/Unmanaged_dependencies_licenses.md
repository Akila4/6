# List of unmanaged dependencies and respective licenses

##  Apache License 2.0
*  https://github.com/elastic/eui 

## MIT License
* https://github.com/jquery/jquery
* https://github.com/ninty9notout/jquery-shake 
* https://github.com/malsup/blockui/
* https://github.com/necolas/normalize.css
* https://github.com/js-cookie/js-cookie
* https://github.com/osano/cookieconsent
* https://github.com/twbs/bootstrap/
