/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const constants = require('../server/routes/lib/constants.js')

import uiRoutes from "ui/routes"
import "ui/autoload/styles"
import "./less/main.less"
import chrome from "ui/chrome"
import $ from "jquery"

const identity = chrome.getInjected('identity')
window.rorIdentity = Object.assign({}, identity)

const access = identity.kibanaAccess || ''

let hiddenApps = identity.hiddenApps


const showReportLink = identity.hiddenApps && identity.hiddenApps.includes("kibana:stack_management")

function addExtraBodyClasses() {
  const extraBodyClasses = ["ror-user_" + identity.username]

  if (identity.groupCurrent) {
    extraBodyClasses.push("ror-group_" + identity.groupCurrent)
  }

  // Hide RW controls
  if (access.toLowerCase().match('^ro')) {
    extraBodyClasses.push("ror-ro")
  }

  // Hide kibana management sidebar for when we need users with hidden management app to download reports
  if (showReportLink && window.location.href.indexOf("/app/kibana#/management") >= 0) {
    extraBodyClasses.push("ror_hidden_kibana_management")
  }

  for (let d of extraBodyClasses) {
    $('body').addClass(d)
  }
}


const isMoreAncientThan720 = chrome.getInjected('isMoreAncientThan720')

if (hiddenApps && hiddenApps.length > 0 && constants.isFree()) {
  alert(`Upgrade to ReadonlyREST PRO or Enterprise to use "kibana_hide_apps" rule!`)
}

let navLinksPost720 = null
//removeIf(isMoreAncientThan720)
if (!isMoreAncientThan720) {
  // COMMENT THIS IF YOU ARE DEVELOPING AN OLDER THAN 7.2.0 KIBANA BUILD
  let theNewPlatform = require('ui/new_platform')
  // Transitional method for 7.2.x
  if (typeof theNewPlatform.getNewPlatform === 'function') {
    theNewPlatform = theNewPlatform.getNewPlatform()
    navLinksPost720 = theNewPlatform.start.core.chrome.navLinks

  } else {
    navLinksPost720 = theNewPlatform.npStart.core.chrome.navLinks
  }
}
//endRemoveIf(isMoreAncientThan720)

// Hide links on page that refer to hidden apps (useful in Kibana home page)
function hideAppsFromSidebar() {
  }

// --- Hiding apps

// Checks if the current path belongs to a permitted app
function checkNavPathPermitted() {
  const urlPathParts = ('' + window.location.pathname).split('/').slice(-2)
  if (urlPathParts[0] !== 'app') {
    return;
  }

  const currentApp = urlPathParts[1] + ':' + (window.location.hash || '').split('?')[0].split('/')[1] //$location.path().replace("/", "")

  if (_.includes(hiddenApps, currentApp)) {
    if (currentApp === "kibana:stack_management") {
      console.log("skip nav checking for kibana management")
      return
    }
    console.log("ReadonlyREST: navigation to " + currentApp + " is not permitted")
    window.location.replace(chrome.addBasePath("/"))
  }
}

window.addEventListener('hashchange', () => {
  console.log("[ROR] hash change detected... ")
  checkNavPathPermitted()
}, false)
checkNavPathPermitted()

// This is done for stubborn, late Kibana versions with React
uiRoutes.addSetupWork(['$location', 'kbnUrl', '$rootScope', '$document', function ($location, kbnUrl, $rootScope, $document) {
  $rootScope.$watch(function () {
    return $location.url();
  }, function (x) {
    if (hiddenApps) {
      hideAppsFromSidebar()
    }
    addExtraBodyClasses()
  })
}])
