/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
// This component is extracted from EUI, which is released under Apache License 2.0
/*
* Licensed to Elasticsearch B.V. under one or more contributor
* license agreements. See the NOTICE file distributed with
* this work for additional information regarding copyright
* ownership. Elasticsearch B.V. licenses this file to you under
* the Apache License, Version 2.0 (the "License"); you may
* not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/
import * as React from 'react';
import { Component, } from 'react';
import classNames from 'classnames';
import { cascadingMenuKeyCodes, findPopoverPosition, getElementZIndex, getTransitionTimings } from '../services/popoverService';
import { OutsideClickDetector } from './outsideClickDetector';
import { Panel } from './panel';
import { Portal } from './portal';
const anchorPositionToPopoverPositionMap = {
    up: 'top',
    right: 'right',
    down: 'bottom',
    left: 'left',
};
export function getPopoverPositionFromAnchorPosition(anchorPosition) {
    const [, primaryPosition] = anchorPosition.match(/^(.*?)[A-Z]/);
    return anchorPositionToPopoverPositionMap[primaryPosition];
}
export function getPopoverAlignFromAnchorPosition(anchorPosition) {
    const [, align] = anchorPosition.match(/([A-Z].*)/);
    return anchorPositionToPopoverPositionMap[align.toLowerCase()];
}
const anchorPositionToClassNameMap = {
    upCenter: 'euiPopover--anchorUpCenter',
    upLeft: 'euiPopover--anchorUpLeft',
    upRight: 'euiPopover--anchorUpRight',
    downCenter: 'euiPopover--anchorDownCenter',
    downLeft: 'euiPopover--anchorDownLeft',
    downRight: 'euiPopover--anchorDownRight',
    leftCenter: 'euiPopover--anchorLeftCenter',
    leftUp: 'euiPopover--anchorLeftUp',
    leftDown: 'euiPopover--anchorLeftDown',
    rightCenter: 'euiPopover--anchorRightCenter',
    rightUp: 'euiPopover--anchorRightUp',
    rightDown: 'euiPopover--anchorRightDown',
};
const displayToClassNameMap = {
    inlineBlock: undefined,
    block: 'euiPopover--displayBlock',
};
const DEFAULT_POPOVER_STYLES = {
    top: 50,
    left: 50,
};
export class Popover extends Component {
    constructor(props) {
        super(props);
        this.button = null;
        this.panel = null;
        this.onKeyDown = (e) => {
            if (e.keyCode === cascadingMenuKeyCodes.ESCAPE) {
                if (this.state.isOpenStable || this.state.isOpening) {
                    e.preventDefault();
                    e.stopPropagation();
                    this.props.closePopover();
                }
            }
        };
        this.positionPopover = (allowEnforcePosition) => {
            if (this.button == null || this.panel == null)
                return;
            const { anchorPosition } = this.props;
            let position = getPopoverPositionFromAnchorPosition(anchorPosition);
            let forcePosition;
            if (allowEnforcePosition && this.state.isOpenStable && this.state.openPosition != null) {
                position = this.state.openPosition;
                forcePosition = true;
            }
            const { top, left, arrow, anchorBoundingBox, } = findPopoverPosition({
                container: this.props.container,
                position,
                forcePosition,
                align: getPopoverAlignFromAnchorPosition(anchorPosition),
                anchor: this.button,
                popover: this.panel,
                offset: 16,
                arrowConfig: {
                    arrowWidth: 24,
                    arrowBuffer: 10,
                }
            });
            // the popover's z-index must inherit from the button
            // this keeps a button's popover under a flyout that would cover the button
            // but a popover triggered inside a flyout will appear over that flyout
            const zIndex = getElementZIndex(this.button, this.panel) + 2000;
            const popoverStyles = {
                top,
                left: anchorBoundingBox
                    ? anchorBoundingBox.left
                    : left,
                zIndex,
            };
            const positionWithRegardToTrigger = "bottom";
            const willRenderArrow = this.props.hasArrow;
            const arrowStyles = willRenderArrow ? arrow : undefined;
            const arrowPosition = positionWithRegardToTrigger;
            this.setState({
                popoverStyles,
                arrowStyles,
                arrowPosition,
                openPosition: positionWithRegardToTrigger,
            });
        };
        this.positionPopoverFixed = () => {
            this.positionPopover(true);
        };
        this.positionPopoverFluid = () => {
            this.positionPopover(false);
        };
        this.panelRef = (node) => {
            this.panel = node;
            this.props.panelRef && this.props.panelRef(node);
            if (node == null) {
                // panel has unmounted, restore the state defaults
                this.setState({
                    popoverStyles: DEFAULT_POPOVER_STYLES,
                    arrowStyles: {},
                    arrowPosition: null,
                    openPosition: null,
                    isOpenStable: false,
                });
                window.removeEventListener('resize', this.positionPopoverFluid);
            }
            else {
                // panel is coming into existence
                this.positionPopoverFluid();
                window.addEventListener('resize', this.positionPopoverFluid);
            }
        };
        this.buttonRef = (node) => {
            this.button = node;
            this.props.buttonRef && this.props.buttonRef(node);
        };
        this.state = {
            prevProps: {
                isOpen: props.isOpen,
            },
            suppressingPopover: this.props.isOpen,
            isClosing: false,
            isOpening: false,
            popoverStyles: DEFAULT_POPOVER_STYLES,
            arrowStyles: {},
            arrowPosition: null,
            openPosition: null,
            isOpenStable: false
        };
    }
    static getDerivedStateFromProps(nextProps, prevState) {
        if (prevState.prevProps.isOpen && !nextProps.isOpen) {
            return {
                prevProps: {
                    isOpen: nextProps.isOpen,
                },
                isClosing: true,
                isOpening: false,
            };
        }
        if (prevState.prevProps.isOpen !== nextProps.isOpen) {
            return {
                prevProps: {
                    isOpen: nextProps.isOpen,
                },
            };
        }
        return null;
    }
    componentDidMount() {
        if (this.state.suppressingPopover) {
            // component was created with isOpen=true; now that it's mounted
            // stop suppressing and start opening
            this.setState({ suppressingPopover: false, isOpening: true }); // eslint-disable-line react/no-did-mount-set-state
        }
        if (this.props.repositionOnScroll) {
            window.addEventListener('scroll', this.positionPopoverFixed);
        }
    }
    componentDidUpdate(prevProps) {
        // The popover is being opened.
        if (!prevProps.isOpen && this.props.isOpen) {
            clearTimeout(this.closingTransitionTimeout);
            // We need to set this state a beat after the render takes place, so that the CSS
            // transition can take effect.
            this.closingTransitionAnimationFrame = window.requestAnimationFrame(() => {
                this.setState({
                    isOpening: true,
                });
            });
            // for each child element of `this.panel`, find any transition duration we should wait for before stabilizing
            const { durationMatch, delayMatch } = Array.prototype.slice
                .call(this.panel ? this.panel.children : [])
                .reduce(({ durationMatch, delayMatch }, element) => {
                const transitionTimings = getTransitionTimings(element);
                return {
                    durationMatch: Math.max(durationMatch, transitionTimings.durationMatch),
                    delayMatch: Math.max(delayMatch, transitionTimings.delayMatch),
                };
            }, { durationMatch: 0, delayMatch: 0 });
            this.respositionTimeout = window.setTimeout(() => {
                this.setState({ isOpenStable: true }, () => {
                    this.positionPopoverFixed();
                });
            }, durationMatch + delayMatch);
        }
        // update scroll listener
        if (prevProps.repositionOnScroll !== this.props.repositionOnScroll) {
            if (this.props.repositionOnScroll) {
                window.addEventListener('scroll', this.positionPopoverFixed);
            }
            else {
                window.removeEventListener('scroll', this.positionPopoverFixed);
            }
        }
        // The popover is being closed.
        if (prevProps.isOpen && !this.props.isOpen) {
            // If the user has just closed the popover, queue up the removal of the content after the
            // transition is complete.
            this.closingTransitionTimeout = window.setTimeout(() => {
                this.setState({
                    isClosing: false,
                });
            }, 250);
        }
    }
    componentWillUnmount() {
        window.removeEventListener('scroll', this.positionPopoverFixed);
        clearTimeout(this.respositionTimeout);
        clearTimeout(this.closingTransitionTimeout);
        cancelAnimationFrame(this.closingTransitionAnimationFrame);
    }
    render() {
        const _a = this.props, { anchorClassName, anchorPosition, button, buttonRef, isOpen, withTitle, children, className, closePopover, panelPaddingSize, panelRef, popoverRef, hasArrow, repositionOnScroll, display, badgeLabel, badgeTitle } = _a, rest = __rest(_a, ["anchorClassName", "anchorPosition", "button", "buttonRef", "isOpen", "withTitle", "children", "className", "closePopover", "panelPaddingSize", "panelRef", "popoverRef", "hasArrow", "repositionOnScroll", "display", "badgeLabel", "badgeTitle"]);
        const classes = classNames('euiPopover', anchorPosition ? anchorPositionToClassNameMap[anchorPosition] : null, display ? displayToClassNameMap[display] : null, {
            'euiPopover-isOpen': this.state.isOpening,
            'euiPopover--withTitle': withTitle,
        }, className);
        const anchorClasses = classNames('euiPopover__anchor', anchorClassName);
        const panelClasses = classNames('euiPopover__panel', `euiPopover__panel--${this.state.arrowPosition}`, { 'euiPopover__panel-isOpen': this.state.isOpening }, { 'euiPopover__panel-withTitle': withTitle });
        let panel;
        if (!this.state.suppressingPopover && (isOpen || this.state.isClosing)) {
            const arrowClassNames = classNames('euiPopover__panelArrow', `euiPopover__panelArrow--${this.state.arrowPosition}`);
            panel = (React.createElement(Portal, null,
                React.createElement(Panel, { panelRef: this.panelRef, className: panelClasses, paddingSize: panelPaddingSize, style: this.state.popoverStyles },
                    React.createElement("div", { className: arrowClassNames, style: this.state.arrowStyles }),
                    React.createElement("div", null, children))));
        }
        let optionalBadge;
        if (badgeLabel) {
            optionalBadge = (React.createElement("div", null,
                React.createElement("span", Object.assign({ className: classNames('euiNotificationBadge euiHeaderNotification'), title: badgeTitle }, rest), badgeLabel)));
        }
        return (React.createElement(OutsideClickDetector, { isDisabled: !isOpen, onOutsideClick: closePopover },
            React.createElement("div", Object.assign({ className: classes, onKeyDown: this.onKeyDown, ref: popoverRef }, rest),
                React.createElement("div", { className: anchorClasses, ref: this.buttonRef },
                    optionalBadge,
                    button instanceof HTMLElement ? null : button),
                panel)));
    }
}
Popover.defaultProps = {
    isOpen: false,
    anchorPosition: 'downLeft',
    panelPaddingSize: 'm',
    hasArrow: true,
    display: 'inlineBlock',
};
