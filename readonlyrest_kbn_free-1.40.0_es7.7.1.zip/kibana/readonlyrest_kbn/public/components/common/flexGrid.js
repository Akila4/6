/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
// This component is extracted from EUI, which is released under Apache License 2.0
/*
 * Licensed to Elasticsearch B.V. under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch B.V. licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
import React from 'react';
import classNames from 'classnames';
const directionToClassNameMap = {
    row: null,
    column: 'euiFlexGrid--directionColumn',
};
const gutterSizeToClassNameMap = {
    none: 'euiFlexGrid--gutterNone',
    s: 'euiFlexGrid--gutterSmall',
    m: 'euiFlexGrid--gutterMedium',
    l: 'euiFlexGrid--gutterLarge',
    xl: 'euiFlexGrid--gutterXLarge',
};
const columnsToClassNameMap = {
    0: 'euiFlexGrid--wrap',
    1: 'euiFlexGrid--single',
    2: 'euiFlexGrid--halves',
    3: 'euiFlexGrid--thirds',
    4: 'euiFlexGrid--fourths',
};
export const FlexGrid = (_a) => {
    var { children, className, gutterSize = 'l', direction = 'row', responsive = true, columns = 0, component: Component = 'div' } = _a, rest = __rest(_a, ["children", "className", "gutterSize", "direction", "responsive", "columns", "component"]);
    const classes = classNames('euiFlexGrid', gutterSize ? gutterSizeToClassNameMap[gutterSize] : undefined, columns != null ? columnsToClassNameMap[columns] : undefined, direction ? directionToClassNameMap[direction] : undefined, {
        'euiFlexGrid--responsive': responsive,
    }, className);
    return (
    // @ts-ignore
    React.createElement(Component, Object.assign({ className: classes }, rest), children));
};
