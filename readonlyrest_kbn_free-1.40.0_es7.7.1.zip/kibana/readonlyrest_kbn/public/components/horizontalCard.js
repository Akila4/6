/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
import React from 'react';
import { FlexGrid } from "./common/flexGrid";
import { FlexItem } from "./common/flexItem";
import { Text } from "./common/text";
import { Panel } from "./common/panel";
export const HorizontalCard = ({ imagePath, description }) => {
    return (React.createElement(Panel, null,
        React.createElement(FlexGrid, { columns: 3, gutterSize: "none" },
            React.createElement(FlexItem, null,
                React.createElement("img", { src: imagePath, alt: imagePath, width: "85%" })),
            React.createElement(FlexItem, { grow: 2 },
                React.createElement(Text, { size: "s" },
                    React.createElement("p", null, description))))));
};
