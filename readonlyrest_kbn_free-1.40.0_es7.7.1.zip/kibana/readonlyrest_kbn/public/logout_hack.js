/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */


import $ from "jquery"
import chrome from "ui/chrome"
import icons from './icons.js'

const expiryDate = new Date(10295291238974)

// Injecting kibana version as body classes for per-version CSS
const kibanaVersion = chrome.getXsrfToken()
const kibanaMajor = "kbn_" + kibanaVersion.substr(0, 1)
const kibanaMajorMinor = "kbn_" + kibanaVersion.substr(0, kibanaVersion.length - 2).replace(/\./g, "")
$('body').addClass(kibanaMajor).addClass(kibanaMajorMinor)


// Add the button to the side bar
icons.mkRorBar()

